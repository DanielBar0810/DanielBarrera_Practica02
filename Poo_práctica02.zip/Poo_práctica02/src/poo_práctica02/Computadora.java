
package poo_práctica02;

import java.util.Random;



public class Computadora extends personaje{
    private int tHealth;
    
    public Computadora()
    {
        super("Computadora",250,75,20,0.50,"Desinstalamiento");
        this.tHealth=super.getHealth();
    }
    
    public void aumentarDefensa()
    {
        Random r= new Random();
        int a = r.nextInt(200);
        if(a>150&&((double)super.getHealth()/(double) this.tHealth)<=0.20)
        {
            int defense = super.getDefense();
            defense+=5;
            super.setDefense(defense);
            System.out.println("Defensa aumentada");
        }
    }
    
    public void Ganador()
    {
        System.out.println(super.getName() + " :Has sido desinstalado");
    }
    
}
