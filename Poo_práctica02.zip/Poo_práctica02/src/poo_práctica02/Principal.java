
package poo_práctica02;

import java.util.Random;
import java.util.Scanner;

public class Principal {
    
    
    public static void main(String[] args) {
        int rondas=0;
        String  batalla,pers,opon;
        Caballero caballero = new Caballero();
        Mago mago = new Mago();
        Computadora computadora = new Computadora();
        
        Scanner sc = new Scanner(System.in);
        
        
        System.out.println("Bienvenidos al juego");
        
        
        System.out.println("ELIGE UN PERSONAJE");
        System.out.println("A.Caballero");
        System.out.println("B.Mago");
        pers=sc.next();
        
        
        System.out.println("ELIGE UN PERSONAJE PARA SU OPONENTE");
        System.out.println("A.Caballero");
        System.out.println("B.Mago");
        System.out.println("D.Computadora");
        opon=sc.next();
        
        while(pers.contains(opon))
        {
            System.out.println("");
            System.out.println("ELIGE UN PERSONAJE PARA SU OPONENTE");
            System.out.println("A.Caballero");
            System.out.println("B.Mago");
            System.out.println("D.Computadora");
            opon=sc.next();
        }
        
        batalla=pers.trim()+opon.trim();
        
        switch(batalla)
        {
            case "AB" -> {
                while(caballero.alive()&&mago.alive())
                {
                    rondas++;
                    System.out.println("Ronda: " + rondas);
                    if(pelea(mago.getTa())) 
                    {
                        caballero.Lastimado(mago.getAttack(),mago.getTipeA());
                    }
                    else caballero.Esquivar();
                    if(pelea(caballero.getTa()))
                    {
                        mago.Lastimado(caballero.getAttack(), caballero.getTipeA());
                    } else mago.Esquivar();
                    caballero.aumentarSalud();
                    mago.aumentarAtaque();
                    if (mago.alive()) mago.Ganador();
                    else caballero.Ganador();
                    
                    
                    
                }
            }
            
            case "AD" -> {
                while(caballero.alive() && computadora.alive())
                {
                    rondas++;
                    if(pelea(caballero.getTa()))
                    {
                        computadora.Lastimado(caballero.getAttack(),caballero.getTipeA());
                    }else computadora.Esquivar();
                    if(pelea(computadora.getTa()))
                    {
                        caballero.Lastimado(computadora.getAttack(), computadora.getTipeA());
                    }else caballero.Esquivar();
                    caballero.aumentarSalud();
                    computadora.aumentarDefensa();
                    if (computadora.alive()) computadora.Ganador();
                    else caballero.Ganador();
                    
                }
            }
                 
            case "BA" -> {
                while(mago.alive() && caballero.alive())
                {
                    rondas++;
                    if(pelea(caballero.getTa()))
                    {
                        mago.Lastimado(caballero.getAttack(),caballero.getTipeA());
                    }else mago.Esquivar();
                    if(pelea(mago.getTa()))
                    {
                        caballero.Lastimado(mago.getAttack(), mago.getTipeA());
                    }else caballero.Esquivar();
                    caballero.aumentarSalud();
                    mago.aumentarAtaque();
                    if (mago.alive()) mago.Ganador();
                    else caballero.Ganador();
                    
                }
            }
            case "BD" -> {
                while(mago.alive() && computadora.alive())
                {
                    rondas++;
                    if(pelea(mago.getTa()))
                    {
                        computadora.Lastimado(mago.getAttack(),mago.getTipeA());
                    }else computadora.Esquivar();
                    if(pelea(computadora.getTa()))
                    {
                        mago.Lastimado(computadora.getAttack(), computadora.getTipeA());
                    }else mago.Esquivar();
                    mago.aumentarAtaque();
                    computadora.aumentarDefensa();
                    if (computadora.alive()) computadora.Ganador();
                    else mago.Ganador();
                    
                }
            }
                 
            default -> System.out.println("La Opcion no es valida");
                
                
        }
        
        }
    
       public static boolean pelea(double _ta)
        {
            boolean flag = false;
            Random n = new  Random();
            int valor=n.nextInt(100);
            
            if(valor<(int)(_ta*100)) flag=true;
            return flag;
    }
    
}
    

