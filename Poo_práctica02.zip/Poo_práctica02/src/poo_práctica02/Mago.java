
package poo_práctica02;

import java.util.Random;
        
public class Mago extends personaje{
    
    private int tlife;
    
    public Mago()
    {
        super("Mago",75,40,5,0.6,"Hechizo");
        this.tlife =super.getHealth();
    }
    
    public void aumentarAtaque()
    {
      Random r = new Random();
      int a = r.nextInt(200);
      if(a>100&&a<150&&this.getHealth()<=50)
      {
          int attack = this.getAttack();
          attack+=3;
          this.setAttack(attack);
          
          System.out.println("Ataque aumentado");
      }
    }
    
    public void Ganador()
    {
        System.out.println(super.getName() + " :Mi magia supera tus habilidades");
    }
    
}
