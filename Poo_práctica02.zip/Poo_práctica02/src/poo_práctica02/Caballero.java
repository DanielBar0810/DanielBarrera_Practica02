
package poo_práctica02;

import java.util.Random;

public class Caballero extends personaje{
    private int tHealth;
    
    public Caballero()
    {
        super("Caballero",150,80,50,0.75,"Tajo preciso");
        this.tHealth=super.getHealth();
    }
    
    public void aumentarSalud()
    {
        Random r= new Random();
        int a = r.nextInt(200);
        if(a<50&&((double)super.getHealth()/75.0)<0.5)
        {
            int health = super.getHealth();
            health+=8;
            super.setDefense(health);
            System.out.println("Vida aumentada");
        }
    }
    
    public void Ganador()
    {
        System.out.println(super.getName()+ ": Un victoria honorable");
    }
}
