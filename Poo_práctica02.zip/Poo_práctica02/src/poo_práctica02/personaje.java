
package poo_práctica02;

/*
Primero se crea la clase personaje, y ya creada en este primer apartado se definen los atributos.
*/
    public abstract class personaje {
    private String name;
    private int health;
    private int attack;
    private int defense;
    private double ta;
    private String tipeA;
    
    /*
    Esta segunda parte del codigo utilizamos el metodo constructor para crear un objeto, en este caso un personaje
    a partir de la clase personaje ya creada.
    */
     public personaje(String _name_,int _health_, int _attack_,int _defense_,double _ta_,String _tipeA_) 
  {
    name= _name_;
    health=_health_;
    attack=_attack_;
    defense=_defense_;
    ta=_ta_;
    tipeA=_tipeA_;
  }
    /*
    Este apartado es para realizar la encapsulación
    */
    
   public String getName()
  {
      return this.name;  
  }
   
  public void setNombre(String _name )
  {
      this.name=_name;
  }

    public int getHealth() {
        return health;
    }

    public void setHealth(int _health) {
        this.health = _health;
    }

    public int getAttack() {
        return attack;
    }

    public void setAttack(int _attack) {
        this.attack = _attack;
    }

    public int getDefense() {
        return defense;
    }

    public void setDefense(int _defense) {
        this.defense = _defense;
    }

    public double getTa() {
        return ta;
    }

    public void setTa(double _ta) {
        this.ta = _ta;
    }

    public String getTipeA() {
        return tipeA;
    }

    public void setTipeA(String _tipeA) {
        this.tipeA = _tipeA;
    }
        
        
    /*
    Finalmente en este apartado se crean los distintos metodos del personaje, en los que tenemos el ser atacado y
    el metodo de esquivar, que también incluye un bool para determinar si este sigue con vida o no. 
    Finalizando así el codigo.
    */
    
    public void Lastimado(int _ataque, String _tipo)
  {
      int vida_res =this.health;
      int danhorecibido = _ataque - this.defense;
      if(danhorecibido>0)
      {
          vida_res-=danhorecibido;
          System.out.println(this.getName() +" " +" Ha sido atacado con "+ _tipo +" Salud restante: " + danhorecibido);
          
      } else 
      {
          System.out.println( "El ataque" + _tipo + " demasido debil para dañar a " + this.getName());
      }
      if(vida_res<0) vida_res=0;
      this.health=vida_res;
      System.out.println(this.getName() + " Tu vida actual es de: " + this.health);
  }
    
 
    
    public void Esquivar()
	{
	System.out.println(this.name+"¡Lo ha esquivado!");
	}
    
    public boolean alive()
    {
        boolean life = true;
        
        if(this.getHealth()<=0) life = false;
        
        return life;
    }
    
  public abstract void Ganador();
    
}


